var mongoose = require("mongoose");
const { v4: uuidv4 } = require('uuid');
const crypto = require("crypto");


var userSchema = new mongoose.Schema(
    {
    
        first_name: {
            type: String,
            required: false,
            trim: true,
        },

        last_name: {
            type: String,
            required: false,
            trim: true,
        },

        gender: {
            type: String,
            required: false
        },
       
        email: {
            type: String,
            trim: true,
            required: true,
            unique: true,
        },

        department: {
               type: String,
               required: false
        },

        myscedule: {
            type: Array,
            required:false
        },
        
        role: {
            type: String,
            default: "",
        },
        
        salt: String,
        encryptedPassword: {
            type: String,
            required: true
        },
   },
    { timestamps: true }
);

userSchema.virtual("password")
    .set(function (password) {
        this._password = password;
        this.salt = uuidv4();
        this.encryptedPassword = this.securePassword(password);
    })
    .get(function () {
        return this._password;
    });

userSchema.methods = {
    securePassword: function (pass) {
        if (pass == "") {
            return "";
        }
        try {
            return crypto.createHmac("sha256", this.salt)
                .update(pass)
                .digest("hex")
        } catch (error) {
            return "";
        }
    },
    authenticate: function (pass) {
        return this.securePassword(pass) === this.encryptedPassword
    }
}

module.exports = mongoose.model("User", userSchema);
