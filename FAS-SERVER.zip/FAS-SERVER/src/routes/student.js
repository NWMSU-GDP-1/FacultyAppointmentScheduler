const express =require("express");
const { getAllFaculties } = require("../controllers/student");
const router = express.Router();


//router.param('userId', getUserById);


router.get('/faculties',getAllFaculties)




module.exports = router;