const User = require("../models/user")


exports.getAllFaculties = ( req , res) => {

    User.find({role: "Faculty"})
    .exec((err, faculties) =>{
        if(err || faculties.length == 0) {
            return res.status(400).json({
              error: 'No faculties found',
              cause: err
            })

          }
          for( let i=0; i< faculties.length; i++) {
              faculties[i].salt = undefined
              faculties[i].encryptedPassword = undefined
          }
          res.json(faculties)

    })
  

}