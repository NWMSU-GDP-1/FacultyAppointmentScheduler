const User = require("../models/user");
const _ = require("lodash");
const jwt = require('jsonwebtoken');
const express_jwt = require("express-jwt")

exports.getUserById = (req, res, next, id) => {
    User.findById(id)
    .exec((err, user) => {
        if (err) {
            return res.status(400).json({
                error: "User not found"
            });
        }
        removeSensitiveUserData(user);
        req.profile = user;
        next();
    });
}



exports.signin = (req, res) => {

  const {email, password} = req.body;
  User.findOne({email})
  .exec((err, user) => {
    if(err || !user) {
      return res.status(400).json({
        error: 'Couldnt not found user ',
        cause: err
      })
    }

    if(!user.authenticate(password)) {
      return res.status(401).json({
        error: 'invalid password'
      })
    }
    const privateKey ="nikhil" ;
    const token = jwt.sign({_id: user._id, expiry: Date.now()}, privateKey)
    const { _id, first_name, last_name, email } = user;
    return res.json({ token, user: { _id, first_name, last_name, email } });
  })

}

exports.signupUser = (req,res) => {

  const payload = {...req.body};


  const user =  new User(payload);
  user.save((err, user) => {
    if(err) {
      console.log("failed creating user", err)
      return res.send("Failed during creating User" + err)
    }
       removeSensitiveUserData(user);
       console.log("user saved to DB: ",user)
        return res.send(user)
    })
}


exports.isUserSignedIn = express_jwt({
  secret: "nikhil",algorithms: ['sha1', 'RS256', 'HS256']
});




exports.isSessionValid = (req, res, next) => {
  let isValid = req.user._id && req.profile._id && (req.user._id == req.profile._id);
  if(!isValid) {
    return res.status(401).json({
      error: "Auth error"
    })
  }
  next();
}

const removeSensitiveUserData = (user) => {
  user.encryptedPassword = undefined;
  user.salt = undefined;
  user.createdAt = undefined;
  user.updatedAt = undefined;
}

