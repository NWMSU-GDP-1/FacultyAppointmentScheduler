var cors = require('cors')
const mongoose = require("mongoose");
var express = require('express');
var app = express();
var cookieParser = require('cookie-parser');

const authRoutes = require("./src/routes/auth")
const studRoutes = require("./src/routes/student")




const connectionString = "mongodb+srv://kvnikhil:KVniki_12212@cluster0.acnzb.mongodb.net/?retryWrites=true&w=majority";
const port = process.env.PORT || 4000;

// mongodb connection
mongoose.connect(connectionString,{useNewUrlParser: true, useUnifiedTopology: true}); 

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:')); 
db.once("open", function(){
   console.log("🟢 Connection to DB succeeded");
    app.listen(port, async() => {
        console.log("🟢 server is up and running at "+ port);
    })
});

// middlewares
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
app.use(cors())

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// routes
app.use("/api/auth", authRoutes);
app.use("/api/student", studRoutes)


app.get("/myname",(req , res )=>{
    res.json({role:"Faculty"})
})

app.post("/myspace",(reg , res )=>{
    res.json({role:"Faculty"})
})

app.get("/fun",(req , res) => {
    res.json({gender:"Male"})
})

app.get("/", (req,res) => {
   return res.send("hiiii")
})




process.on('uncaughtException', function(err) {
    console.log('Caught exception: ' + err);
});